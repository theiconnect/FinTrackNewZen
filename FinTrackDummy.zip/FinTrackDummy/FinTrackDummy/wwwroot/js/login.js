//document.getElementById("loginForm").addEventListener("submit", function(e) {
//  e.preventDefault();

//  const emailPhone = document.getElementById("emailPhone").value;
//  const password = document.getElementById("password").value;

//  if (emailPhone && password) {
//      alert("Login successful!");
//      window.location.href = "Test1%20(1).html"; // Redirect to Test1 (1).html
//  } else {
//      alert("Please fill in all fields.");
//  }
//});